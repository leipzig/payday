<? $cfg[1] = "?dtc=F5F4D3&ntc=E8E8E8" ?>
<? $cfg[2] = "?tw=120&th=135&fsm=13&fsn=10&cs=-0&ntc=EEEEEE&dtc=BBBBBB&fsd=12&fwd=2" ?>
<? $cfg[3] = "?ny=1&tw=400&cp=6&th=300&fsm=24&fsd=14&fsn=14&fwd=1&fwn=1&al=2&nbc=DAD6BC&ntc=CBC6A1&dtc=C3BD93&mtc=EEECE0" ?>